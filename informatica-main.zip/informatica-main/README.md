# informatica
trabajo practico informatica
